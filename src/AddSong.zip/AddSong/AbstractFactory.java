package AddSong;

public interface AbstractFactory
{
    FileF fileCreate(String type);
}
