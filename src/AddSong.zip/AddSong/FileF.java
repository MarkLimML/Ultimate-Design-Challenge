package AddSong;

import javafx.stage.FileChooser;

public interface FileF
{
    FileChooser chooser = new FileChooser();

    FileF fileCreate();
}
