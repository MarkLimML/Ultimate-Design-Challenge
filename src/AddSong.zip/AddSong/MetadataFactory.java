package AddSong;

import java.util.ArrayList;

public interface MetadataFactory
{
    public Metadata create(String type);
}
